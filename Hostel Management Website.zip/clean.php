<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title>Room Service</title>
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST["name"];
        $block = $_POST["BLOCK"];
        $roomNo = $_POST["roomno"];
        $service = $_POST["service"];
        
        echo "<h1>Service Request Details</h1>";
        echo "<p><strong>Name:</strong> $name</p>";
        echo "<p><strong>Block:</strong> $block</p>";
        echo "<p><strong>Room Number:</strong> $roomNo</p>";
        echo "<p><strong>Service Needed:</strong> $service</p>";
        echo "<p><strong>YOUR REQUEST ACCEPTED </strong> </p>";
    } else {
        echo "<p>No data submitted.</p>";
    }
    ?>
</body>
</html>